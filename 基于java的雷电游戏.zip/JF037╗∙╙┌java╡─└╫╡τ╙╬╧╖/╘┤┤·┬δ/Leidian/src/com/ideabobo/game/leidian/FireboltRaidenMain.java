package com.ideabobo.game.leidian;

import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class FireboltRaidenMain extends Frame {

	private static final long serialVersionUID = 1L;

	public FireboltRaidenMain() {
		setTitle("�ɻ���ս");
		setResizable(false);
		GamePanel main = new GamePanel();
		add(main, "Center");
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		pack();
	}

	public static void main(String args[]) {
		FireboltRaidenMain frame = new FireboltRaidenMain();
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
}
