package com.ideabobo.game.leidian;

import java.awt.Image;

public class BattleShot extends Hero {

	public BattleShot(float x, float y, float vx, float vy, Image image) {
		super(x, y, vx, vy, image);
	}
}
