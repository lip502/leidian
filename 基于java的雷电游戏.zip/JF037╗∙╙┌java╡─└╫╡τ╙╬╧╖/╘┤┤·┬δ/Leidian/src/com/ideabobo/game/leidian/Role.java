package com.ideabobo.game.leidian;

import java.awt.Graphics;
import java.awt.Image;

public abstract class Role {
	//����GamePanel����
	protected static GamePanel app;

	protected Image img;

	protected float x;

	protected float y;

	protected float WIDTH;

	protected float HEIGHT;

	private boolean dead;

	protected Role(Image img) {
		this.img = img;
		WIDTH = img.getWidth(app);
		HEIGHT = img.getHeight(app);
		dead = false;
	}

	public boolean isDead() {
		return dead;
	}

	public void dead() {
		dead = true;
	}

	abstract void move();

	protected boolean checkHit(Role chara) {
		return x > chara.x - WIDTH && x < chara.x + chara.WIDTH
				&& y > chara.y - HEIGHT && y < chara.y + chara.HEIGHT;
	}

	public void draw(Graphics g) {
		g.drawImage(img, (int) x, (int) y, app);
	}

	public void drawBurst(Graphics g) {
		g.drawImage(GamePanel.burstImage[0], (int) x, (int) y, app);
	}

}
