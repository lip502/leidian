package com.ideabobo.game.leidian;

import java.awt.Image;

public class Hero extends Role {
	protected float vx;

	protected float vy;

	public Hero(float x, float y, Image tamaImage) {
		super(tamaImage);
		this.x = x - WIDTH / 2.0F;
		this.y = y - HEIGHT / 2.0F;
	}

	public Hero(float x, float y, float vx, float vy, Image tamaImage) {
		super(tamaImage);
		this.x = x - WIDTH / 2.0F;
		this.y = y - HEIGHT / 2.0F;
		this.vx = vx;
		this.vy = vy;
	}

	public void move() {
		x += vx;
		y += vy;
		if (x + WIDTH < 0.0F || x > (float) app.getWidth() || y + HEIGHT < 0.0F
				|| y > (float) app.getHeight())
			dead();
	}

	public boolean checkHit(Role chara) {
		return false;
	}

}
