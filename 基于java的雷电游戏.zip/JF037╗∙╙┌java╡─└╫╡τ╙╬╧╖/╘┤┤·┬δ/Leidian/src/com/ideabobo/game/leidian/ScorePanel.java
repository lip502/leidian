package com.ideabobo.game.leidian;

import java.awt.Dimension;
import java.awt.Panel;

public class ScorePanel extends Panel {
	public static final int WIDTH = 100;

	public static final int HEIGHT = 450;

	private static final long serialVersionUID = 1L;

	public ScorePanel() {
		setPreferredSize(new Dimension(100, 450));
	}

}
